package com.reforzamientospring.springcolombia.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpSession;

@Controller
public class ControllerSession {
    @GetMapping("/")
    public String indexPage(){
        return "index";
    }
    @GetMapping("/form")
    public String formPage(){
        return "form";
    }
    @GetMapping("/data")
    public String showData(Model model, HttpSession session){

        String nombreGuardadoEnSesion = (String) session.getAttribute("savedName");
        String apellidoGuardadoEnSesion = (String) session.getAttribute("savedLastName");
        Integer edadGuardadaEnSesion = (Integer) session.getAttribute("savedAge");

        model.addAttribute("name",nombreGuardadoEnSesion );
        model.addAttribute("lastName", apellidoGuardadoEnSesion);
        model.addAttribute("age", edadGuardadaEnSesion);
        return "data";
    }
    @PostMapping("/postForm")
    public String sendForm(HttpSession session,
                        @RequestParam(name = "inputName") String nombre,
                        @RequestParam(name = "inputLastName") String apellido,
                        @RequestParam(name = "inputAge" )int edad){

        session.setAttribute("savedName",nombre);
        session.setAttribute("savedLastName", apellido);
        session.setAttribute("savedAge",edad);

        System.out.println(session.getAttribute("savedName"));
        return "redirect:/data";
    }
    @GetMapping("/resetData")
    public String deleteData(HttpSession session){
        //session.removeAttribute("inputName");
        session.invalidate();
        return "redirect:/";
    }
}
