package com.reforzamientospring.springcolombia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcolombiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
