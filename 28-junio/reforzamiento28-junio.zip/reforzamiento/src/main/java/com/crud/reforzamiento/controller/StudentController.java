package com.crud.reforzamiento.controller;
//import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.crud.reforzamiento.model.Student;
import com.crud.reforzamiento.services.StudentService;

@Controller
public class StudentController {
    //inyectar, traer y usar StudentService
    @Autowired
    StudentService studentService; 
    
    @GetMapping("/")
    public String formPage(){
        return "studentForm";
    }
    @GetMapping("/data")
    public String data(){
        
        return "data";
    }

    
    //manejar la solicutd post
    @PostMapping("/saveData")
    public String saveStudent(
                            @RequestParam(name = "nameInput") String nombre,
                            @RequestParam(name = "lastNameInput") String apellido,
                            @RequestParam(name = "ageInput") int edad){
        
        Student estudiante = new Student(nombre, apellido, edad);
        //Student estudiante2 = new Student(null, nombre, apellido, edad);
        studentService.saveStudent(estudiante);

        return "redirect:/data";
    }
}
