package com.crud.reforzamiento.services;

import java.util.List;

//import org.hibernate.mapping.List;
//import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.reforzamiento.model.Student;
import com.crud.reforzamiento.repository.StudentRepository;

@Service
public class StudentService {
    //Autowired es el equivalente a inyectar dependencias
    //se puede trabajar con una clase sin crear el objeto como tal
    @Autowired
    StudentRepository studentRepository;
    

    //método para guardar estudiantes
    public Student saveStudent(Student student){
        return studentRepository.save(student);
    }
    public List<Student> showStudents(){
        return (List<Student>) studentRepository.findAll();
    }
}
