package com.reforzamiento.web.reforzamientochile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReforzamientochileApplicationTests {

	@Test
	void contextLoads() {
	}

}
