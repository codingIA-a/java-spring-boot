package com.reforzamiento.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import jakarta.servlet.http.HttpSession;
   
@Controller()
public class JuegoController {
    private String[] preguntas = {
        "¿Cual es la capital de Francia?",
        "En que año empezó la segunda guerra mundial?",
        "¿Quien es cribió 'Cien años de Soledad'?"
    };
    
    private String[][] opciones = {
        {"Madrid","PAris","Berlín","Londres"},
        {"1980","1920","1939","1945"},
        {"Autor 1","Gabriel García Marquez","Autor 3 ","Autor 4"}
    };
    private int[] respuestas = {1, 2, 1};

    @GetMapping("/juego")
    public String empezarJuego(Model model, HttpSession session ){
        session.setAttribute("puntos",0);
        session.setAttribute("preguntaActual", 0);
        return "juego";
    }

    @GetMapping("/juego/pregunta")
    public String mostrarPregunta(Model model, HttpSession session){
        int preguntaActual = (int) session.getAttribute("preguntaActual");
        model.addAttribute("pregunta", preguntas[preguntaActual]);
        return "pregunta";
    }

}
