package com.reforzamiento.web.reforzamiento21junio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reforzamiento21junioApplicationTests {

	@Test
	void contextLoads() {
	}

}
