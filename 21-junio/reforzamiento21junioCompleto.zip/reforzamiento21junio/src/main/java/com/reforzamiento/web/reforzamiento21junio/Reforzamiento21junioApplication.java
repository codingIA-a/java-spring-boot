package com.reforzamiento.web.reforzamiento21junio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Reforzamiento21junioApplication {

	public static void main(String[] args) {
		SpringApplication.run(Reforzamiento21junioApplication.class, args);
	}

}
