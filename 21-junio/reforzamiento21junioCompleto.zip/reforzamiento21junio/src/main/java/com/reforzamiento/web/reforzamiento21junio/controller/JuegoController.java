package com.reforzamiento.web.reforzamiento21junio.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller()

public class JuegoController {

    private String[] preguntas = {
            "¿Cuál es la capital de Francia?",
            "¿En qué año comenzó la Segunda Guerra Mundial?",
            "¿Quién escribió 'Cien años de soledad'?"
    };

    private String[][] opciones = {
            {"Madrid", "Londres", "París", "Berlín"},
            {"1939", "1941", "1945", "1914"},
            {"Julio Cortázar", "Gabriel García Márquez", "Mario Vargas Llosa", "Pablo Neruda"}
    };
    private int[] respuestas = {2, 0, 1}; // Índices de las respuestas correctas

    @GetMapping("/juego")
    public String empezarJuego(Model model, HttpSession session) {
        session.setAttribute("puntos", 0); // Inicializar puntos a cero
        session.setAttribute("preguntaActual", 0); // Inicializar la primera pregunta
        return "juego";
    }
    
    @GetMapping("/juego/pregunta")
    public String mostrarPregunta(Model model, HttpSession session) {
        int preguntaActual = (int) session.getAttribute("preguntaActual");

        model.addAttribute("pregunta", preguntas[preguntaActual]);
        model.addAttribute("opciones", opciones[preguntaActual]);

        return "pregunta";
    }
    
    

    @PostMapping("/juego/responder")
    public String responderPregunta(HttpServletRequest request, HttpSession session) {
        int preguntaActual = (int) session.getAttribute("preguntaActual");
        int puntos = (int) session.getAttribute("puntos");

        int respuestaUsuario = Integer.parseInt(request.getParameter("opcionSeleccionada"));

        if (respuestaUsuario == respuestas[preguntaActual]) {
            puntos++; // Sumar puntos si la respuesta es correcta
        }

        session.setAttribute("puntos", puntos);

        // Pasar a la siguiente pregunta
        preguntaActual++;
        session.setAttribute("preguntaActual", preguntaActual);

        if (preguntaActual >= preguntas.length) {
            return "redirect:/juego/resultados";
        }

        return "redirect:/juego/pregunta";
    }

    

    @GetMapping("/juego/resultados")
    public String mostrarResultados(Model model, HttpSession session) {
        int puntos = (int) session.getAttribute("puntos");
        model.addAttribute("puntos", puntos);

        return "resultados";
    }
}
